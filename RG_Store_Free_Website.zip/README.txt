# RG Store
Professional clothing-store starter website.

## Important
The sample product names and prices are placeholders. Replace them with your real products, prices and images before publishing.

The WhatsApp order buttons are already connected to: 0325 4511482.
